./dartsHough {image}
This is our final dartboard detector that makes use of strict 
comparisons with expected dartboard features, and approximation 
based on an incomplete feature set. 
(Best Performing - Stage 4 in report)

./dartsHoughO {image}
Our old dartboard detector that only made use of strict comparisons
with expected dartboard features.
(Stage 3 in report)

./darts {image}
Dartboard detector that only uses Viola-Jones classifier.
(Stage 2 in report)

./face {image}
Face detector provided, with ground truths and detector result stats.